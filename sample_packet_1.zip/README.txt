Claim Registry Evidence Packet

Contents
- record/record.json
- record/manifest.json (hashed with its own sha256 entry set to null)
- record/manifest.meta.json (resolved manifest structure including manifest.json self-hash)
- record/attachments/* (optional)
- registry.jsonl (append-only log slice, from genesis through this record)

Verification
1) Install Python 3.10+.
2) From the repository root, run:
   python -m claim_registry verify --root <path_to_unzipped_packet>
