Claim Registry Evidence Packet

Contents
- record/record.json
- record/manifest.json
- record/attachments/* (optional)
- registry.jsonl (append-only log slice, from genesis through this record)

Verification
1) Install Python 3.10+.
2) From the repository root, run:
   python -m claim_registry verify --root <path_to_packet_root>

What verify checks
- Recomputes SHA-256 for normalized claim text, the canonical record JSON, and every attachment.
- Validates record/manifest.json entries match file hashes.
- Validates registry.jsonl forms a hash chain via prev_record_hash.
- Confirms record_id is deterministic from stable fields.
